import os
import asyncio
import aiosqlite
from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command, CommandObject
from aiogram.types import (Message, InlineKeyboardMarkup, InlineKeyboardButton,
                           CallbackQuery)

TOKEN = os.getenv("TELEGRAM_TOKEN")
ADMIN_IDS = {int(x.strip()) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip()}

if not TOKEN:
    raise RuntimeError("Please set TELEGRAM_TOKEN env var")
if not ADMIN_IDS:
    print("[WARN] ADMIN_IDS is empty; admin commands will be disabled")

DB_PATH = "store.db"
bot = Bot(token=TOKEN)
dp = Dispatcher()

# ---------- Utilities ----------
async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
        CREATE TABLE IF NOT EXISTS users (
          user_id INTEGER PRIMARY KEY,
          balance REAL DEFAULT 0
        );""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS stock (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          category TEXT NOT NULL,
          price REAL NOT NULL,
          credential TEXT NOT NULL,
          is_sold INTEGER DEFAULT 0
        );""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS orders (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER,
          stock_id INTEGER,
          price REAL,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );""")
        await db.commit()

async def get_or_create_user(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT balance FROM users WHERE user_id=?", (user_id,))
        row = await cur.fetchone()
        if row is None:
            await db.execute("INSERT INTO users(user_id, balance) VALUES (?, 0)", (user_id,))
            await db.commit()
            return 0.0
        return float(row[0])

async def set_balance(user_id: int, new_balance: float):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("INSERT INTO users(user_id, balance) VALUES(?, ?) ON CONFLICT(user_id) DO UPDATE SET balance=excluded.balance",
                         (user_id, new_balance))
        await db.commit()

async def change_balance(user_id: int, delta: float):
    bal = await get_or_create_user(user_id)
    bal += delta
    if bal < 0: 
        return False
    await set_balance(user_id, bal)
    return True

async def list_categories():
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("""
          SELECT category, COUNT(*) AS cnt, MIN(price) AS minp, MAX(price) AS maxp
          FROM stock WHERE is_sold=0
          GROUP BY category ORDER BY category
        """)
        rows = await cur.fetchall()
        return rows

async def find_item(category: str, max_price: float=None):
    query = "SELECT id, credential, price FROM stock WHERE is_sold=0 AND category=?"
    args = [category]
    if max_price is not None:
        query += " AND price<=?"
        args.append(max_price)
    query += " ORDER BY id ASC LIMIT 1"
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(query, tuple(args))
        return await cur.fetchone()

async def mark_sold(stock_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE stock SET is_sold=1 WHERE id=?", (stock_id,))
        await db.commit()

async def create_order(user_id: int, stock_id: int, price: float):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("INSERT INTO orders(user_id, stock_id, price) VALUES (?,?,?)",
                         (user_id, stock_id, price))
        await db.commit()

def is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS

# ---------- Keyboards ----------
def main_menu_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="💳 شحن الرصيد (يدوي)", callback_data="topup")],
        [InlineKeyboardButton(text="🛍️ الكتالوج / شراء", callback_data="catalog")],
        [InlineKeyboardButton(text="💼 رصيدي", callback_data="balance")]
    ])

def categories_kb(rows):
    buttons = []
    for cat, cnt, minp, maxp in rows:
        text = f"{cat} — {cnt} متاح | {minp:g}~{maxp:g}"
        buttons.append([InlineKeyboardButton(text=text, callback_data=f"cat::{cat}")])
    buttons.append([InlineKeyboardButton(text="🔙 رجوع", callback_data="back_home")])
    return InlineKeyboardMarkup(inline_keyboard=buttons)

def buy_options_kb(category, minp, maxp):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=f"شراء بأقل سعر ({minp:g})", callback_data=f"buy::{category}::min")],
        [InlineKeyboardButton(text="تحديد سقف سعر...", callback_data=f"buy::{category}::cap")],
        [InlineKeyboardButton(text="🔙 رجوع", callback_data="catalog")]
    ])

# ---------- Handlers ----------
@dp.message(Command("start"))
async def start_cmd(m: Message):
    await get_or_create_user(m.from_user.id)
    await m.answer(
        "أهلًا بك 👋\nبوت بيع حسابات تلقائي.\nاختر من القائمة:",
        reply_markup=main_menu_kb()
    )

@dp.message(Command("balance"))
async def balance_cmd(m: Message):
    bal = await get_or_create_user(m.from_user.id)
    await m.answer(f"رصيدك الحالي: {bal:g}$", reply_markup=main_menu_kb())

@dp.callback_query(F.data == "balance")
async def cb_balance(c: CallbackQuery):
    bal = await get_or_create_user(c.from_user.id)
    await c.message.edit_text(f"رصيدك الحالي: {bal:g}$", reply_markup=main_menu_kb())

@dp.callback_query(F.data == "topup")
async def cb_topup(c: CallbackQuery):
    text = (
        "💳 **شحن الرصيد (يدوي)**\n"
        "أرسل لقطة شاشة لإثبات الدفع + المبلغ المراد إضافته.\n"
        "سيتم مراجعتها من الإدارة ثم إضافة الرصيد.\n\n"
        "بعد الإرسال، انتظر رسالة تأكيد منا هنا."
    )
    await c.message.edit_text(text, reply_markup=InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔙 رجوع", callback_data="back_home")]
    ]))

@dp.message(F.photo | F.document | F.text.contains("شحن") | F.caption.contains("شحن"))
async def user_proof(m: Message):
    if is_admin(m.from_user.id):
        return
    uid = m.from_user.id
    mention = m.from_user.mention_html()
    hint = f"طلب شحن من {mention} (user_id={uid}).\nاستخدم: /addbal {uid} <amount>"
    for admin_id in ADMIN_IDS:
        try:
            await bot.copy_message(chat_id=admin_id, from_chat_id=m.chat.id, message_id=m.message_id)
            await bot.send_message(admin_id, hint, parse_mode="HTML")
        except Exception:
            pass

@dp.callback_query(F.data == "catalog")
async def cb_catalog(c: CallbackQuery):
    rows = await list_categories()
    if not rows:
        await c.message.edit_text("لا توجد مخزونات حاليًا.", reply_markup=main_menu_kb())
        return
    await c.message.edit_text("🛍️ اختر فئة الحسابات:", reply_markup=categories_kb(rows))

@dp.callback_query(F.data == "back_home")
async def cb_back_home(c: CallbackQuery):
    await c.message.edit_text("اختر من القائمة:", reply_markup=main_menu_kb())

@dp.callback_query(F.data.startswith("cat::"))
async def cb_pick_category(c: CallbackQuery):
    category = c.data.split("::", 1)[1]
    rows = await list_categories()
    row = next(((cat, cnt, minp, maxp) for cat, cnt, minp, maxp in rows if cat == category), None)
    if not row:
        await c.answer("الفئة غير متاحة الآن", show_alert=True)
        return
    cat, cnt, minp, maxp = row
    text = f"الفئة: {cat}\nمتاح: {cnt}\nالمدى السعري: {minp:g} ~ {maxp:g}\nاختر طريقة الشراء:"
    await c.message.edit_text(text, reply_markup=buy_options_kb(cat, minp, maxp))

@dp.callback_query(F.data.startswith("buy::"))
async def cb_buy(c: CallbackQuery):
    _, category, mode = c.data.split("::", 2)
    bal = await get_or_create_user(c.from_user.id)

    if mode == "min":
        item = await find_item(category)
        if not item:
            await c.answer("لا يوجد مخزون.", show_alert=True)
            return
        stock_id, credential, price = item
        if bal < price:
            await c.answer(f"رصيدك لا يكفي. السعر {price:g}$ ورصيدك {bal:g}$", show_alert=True)
            return
        ok = await change_balance(c.from_user.id, -price)
        if not ok:
            await c.answer("فشل الخصم.", show_alert=True)
            return
        await mark_sold(stock_id)
        await create_order(c.from_user.id, stock_id, price)
        await c.message.edit_text(
            f"✅ تم الشراء: {category}\nالسعر: {price:g}$\n\n**البيانات:**\n`{credential}`",
            parse_mode="Markdown"
        )
        try:
            await bot.send_message(c.from_user.id, f"بيانات حسابك:\n`{credential}`", parse_mode="Markdown")
        except Exception:
            pass
        return

    elif mode == "cap":
        await c.message.edit_text(
            "اكتب لي سقف السعر (رقم فقط)، وسأحاول أجيب لك أرخص حساب ≤ السقف.",
        )
        dp.workflow_state = {"awaiting_cap": {"user": c.from_user.id, "category": category}}
        return

@dp.message()
async def catch_cap(m: Message):
    st = getattr(dp, "workflow_state", {})
    w = st.get("awaiting_cap")
    if not w or w.get("user") != m.from_user.id:
        return
    category = w["category"]
    try:
        cap = float(m.text.strip())
    except Exception:
        await m.reply("من فضلك رقم فقط. جرّب مرة أخرى.")
        return

    item = await find_item(category, max_price=cap)
    if not item:
        await m.reply("لا يوجد عنصر بهذا السقف السعري. جرّب سقفًا أعلى.")
        return
    stock_id, credential, price = item
    bal = await get_or_create_user(m.from_user.id)
    if bal < price:
        await m.reply(f"السعر {price:g}$ ورصيدك {bal:g}$. اشحن رصيدك ثم أعد المحاولة.")
        return

    ok = await change_balance(m.from_user.id, -price)
    if not ok:
        await m.reply("فشل الخصم.")
        return
    await mark_sold(stock_id)
    await create_order(m.from_user.id, stock_id, price)

    await m.reply(
        f"✅ تم الشراء: {category}\nالسعر: {price:g}$\n\n**البيانات:**\n`{credential}`",
        parse_mode="Markdown"
    )
    dp.workflow_state = {}

# ---------- Admin Commands ----------
@dp.message(Command("addbal"))
async def admin_addbal(m: Message, command: CommandObject):
    if not is_admin(m.from_user.id):
        return
    if not command.args:
        await m.reply("الاستخدام: /addbal <user_id> <amount>")
        return
    try:
        uid_str, amt_str = command.args.split()
        uid = int(uid_str)
        amt = float(amt_str)
    except Exception:
        await m.reply("الاستخدام: /addbal <user_id> <amount>")
        return

    ok = await change_balance(uid, amt)
    if ok:
        await m.reply(f"تم إضافة {amt:g}$ إلى {uid}.")
        try:
            await bot.send_message(uid, f"✅ تم شحن رصيدك بـ {amt:g}$.")
        except Exception:
            pass
    else:
        await m.reply("فشل التعديل.")

@dp.message(Command("addstock"))
async def admin_addstock(m: Message, command: CommandObject):
    if not is_admin(m.from_user.id):
        return
    if not command.args:
        await m.reply("الاستخدام: /addstock <category> <price> <credential>")
        return
    try:
        parts = command.args.split()
        category = parts[0]
        price = float(parts[1])
        credential = " ".join(parts[2:])
    except Exception:
        await m.reply("الاستخدام: /addstock <category> <price> <credential>")
        return

    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("INSERT INTO stock(category, price, credential) VALUES (?, ?, ?)",
                         (category, price, credential))
        await db.commit()
    await m.reply("تمت إضافة عنصر للمخزون.")

@dp.message(Command("stock"))
async def admin_stock(m: Message):
    if not is_admin(m.from_user.id):
        return
    rows = await list_categories()
    if not rows:
        await m.reply("لا يوجد مخزون.")
        return
    lines = ["المخزون الحالي:"]
    for cat, cnt, minp, maxp in rows:
        lines.append(f"- {cat}: {cnt} عنصر | {minp:g}~{maxp:g}$")
    await m.reply("\n".join(lines))

# ---------- Runner ----------
async def main():
    await init_db()
    print("Bot started.")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
